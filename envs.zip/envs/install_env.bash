#!bin/bash
# cd scripts && bash bart.bash &
# cd scripts && bash bertext.bash &
# cd scripts && bash clustering.bash &
# cd scripts && bash hertersum.bash &
# cd scripts && bash kakfa.bash &
# cd scripts && bash keyword.bash &
# cd scripts && bash memsum.bash &
# cd scripts && bash multibart.bash &
# cd scripts && bash name_entities.bash &
# cd scripts && bash primera.bash &
# cd scripts && bash simcls.bash &
cd scripts && bash single_root.bash &

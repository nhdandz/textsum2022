#!bin/bash
cd ../
python3 -m venv memsum_envs
source ./memsum_envs/bin/activate
pip install -r scripts/memsum_envs.txt -f https://download.pytorch.org/whl/torch_stable.html

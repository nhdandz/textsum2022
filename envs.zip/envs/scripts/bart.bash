#!bin/bash
cd ../
python3 -m venv bart
source ./bart/bin/activate
# Perform pip-based installation here.
pip install -r ./scripts/bart.txt
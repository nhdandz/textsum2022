#!bin/bash
cd ../
python3 -m venv single_root_envs
source ./single_root_envs/bin/activate
pip install -r ./scripts/single_root_envs.txt

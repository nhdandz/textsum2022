#!bin/bash
cd ../
python3 -m venv multibart
source ./multibart/bin/activate
# Perform pip-based installation here.
pip install -r scripts/multibart.txt
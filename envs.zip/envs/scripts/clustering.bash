#!bin/bash
cd ../
python3 -m venv clustering
source ./clustering/bin/activate
# Perform pip-based installation here.
pip install -r scripts/clustering.txt
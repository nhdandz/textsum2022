#!bin/bash
cd ../
python3 -m venv kakfa
source ./kakfa/bin/activate
# Perform pip-based installation here.
pip install -r scripts/kakfa.txt

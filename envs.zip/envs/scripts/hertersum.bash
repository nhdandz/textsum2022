#!bin/bash
cd ../
python3 -m venv hertersum
source ./hertersum/bin/activate
# Perform pip-based installation here.
pip install -r scripts/hertersum.txt

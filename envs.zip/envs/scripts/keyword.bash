#!bin/bash
cd ../
python3 -m venv keyword
source ./keyword/bin/activate
# Perform pip-based installation here.
pip install -r scripts/keyword.txt
#!bin/bash
cd ../
python3 -m venv name_entities
source ./name_entities/bin/activate
# Perform pip-based installation here.
pip install -r scripts/name_entities.txt
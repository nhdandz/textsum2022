#!bin/bash
cd ../
python3 -m venv simcls
source ./simcls/bin/activate
# cd /media/user01/dd716379-27f0-495c-a373-2f83db4e247a/tupk/TextSum/envs/requirments &&
# Perform pip-based installation here.
pip install -r scripts/simcls.txt
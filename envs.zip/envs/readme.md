copoy ca file envs ra home 
cd envs 
bash install_env.bash
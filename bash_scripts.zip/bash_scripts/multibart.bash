#!/bin/bash
screen -dm multibart
screen -S multibart -X stuff "cd /media/hth/disk1/TextSum/Single/pegasus-xsum
source ~/anaconda3/etc/profile.d/conda.sh && conda activate test
python MultiBartKafka.py
"
#!/bin/bash
screen -dm memsum
screen -S memsum -X stuff "cd /media/hth/disk1/TextSum/Single/MemSum
source /home/hth/envs/memsum_envs/bin/activate && python sub_single_16.py
"

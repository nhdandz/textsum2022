#!/bin/bash
screen -dm single_kafka
screen -S single_kafka -X stuff "cd /media/hth/disk1/TextSum/modules/single_kafka
source /home/hth/envs/single_root_envs/bin/activate && python single_root.py
"

#!/bin/bash
screen -dm app_process_summary
screen -S app_process_summary -X stuff "cd /media/hth/disk1/TextSum/modules/single_kafka
source /home/hth/envs/single_root_envs/bin/activate && python app_process.py
"

#!/bin/bash
screen -dm lsa
screen -S lsa -X stuff "cd /media/hth/disk1/TextSum/Single/TexRank
source ~/anaconda3/etc/profile.d/conda.sh && conda activate kakfa
python lsa.py
"
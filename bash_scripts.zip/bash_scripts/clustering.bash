#!/bin/bash
screen -dm clustering
screen -S clustering -X stuff "cd /media/hth/disk1/TextSum/modules/Text-similarity
source ~/anaconda3/etc/profile.d/conda.sh && conda activate yake
python cluster_app.py
"


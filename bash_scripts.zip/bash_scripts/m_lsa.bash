#!/bin/bash
screen -dm m_lsa
screen -S m_lsa -X stuff "cd /media/hth/disk1/TextSum/Multi/MulTexRank
source ~/anaconda3/etc/profile.d/conda.sh && conda activate kakfa
python multi_lsa.py
"
#!/bin/bash
screen -dm lexrank
screen -S lexrank -X stuff "cd /media/hth/disk1/TextSum/Single/TexRank
source ~/anaconda3/etc/profile.d/conda.sh && conda activate kakfa
python lexrank.py
"
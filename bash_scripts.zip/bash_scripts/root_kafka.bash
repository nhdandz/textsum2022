#!/bin/bash
screen -dm root_kafka
screen -S root_kafka -X stuff "cd /media/hth/disk1/TextSum/modules/root_kafka
source ~/anaconda3/etc/profile.d/conda.sh && conda activate kakfa
python root_kafka.py 
"
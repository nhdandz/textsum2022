#!/bin/bash
screen -dm algo_control
screen -S algo_control -X stuff "cd /media/hth/disk1/TextSum/modules/algorithm_control
source ~/anaconda3/etc/profile.d/conda.sh && conda activate kakfa
python algo_control_app.py 
"
#!/bin/bash
screen -dm hertersum
screen -S hertersum -X stuff "cd /media/hth/disk1/TextSum/Multi/HeterSum
source ~/anaconda3/etc/profile.d/conda.sh && conda activate hertersum
python app.py
"
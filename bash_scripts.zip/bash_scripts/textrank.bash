#!/bin/bash
screen -dm textrank
screen -S textrank -X stuff "cd /media/hth/disk1/TextSum/Single/TexRank
source ~/anaconda3/etc/profile.d/conda.sh && conda activate kakfa
python texrank.py
"
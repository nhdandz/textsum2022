#!/bin/bash
screen -dm keyword
screen -S keyword -X stuff "cd /media/hth/disk1/TextSum/modules/Key-Bert
source ~/anaconda3/etc/profile.d/conda.sh && conda activate keyBert
python app2.py
"
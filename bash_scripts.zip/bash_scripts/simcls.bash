#!/bin/bash
screen -dm simcls
screen -S simcls -X stuff "cd /media/hth/disk1/TextSum/Single/SimCLS2/simcls-pytorch
source ~/anaconda3/etc/profile.d/conda.sh && conda activate SimCLS2
python SimCLSKafka.py
"
#!/bin/bash
screen -dm bart
screen -S bart -X stuff "cd /media/hth/disk1/TextSum/Single/BART
source ~/anaconda3/etc/profile.d/conda.sh && conda activate BART
python KafkaBart.py
"
#!/bin/bash
screen -dm brio
screen -S brio -X stuff "cd /media/hth/disk1/TextSum/Single/pegasus-xsum
source ~/anaconda3/etc/profile.d/conda.sh && conda activate test
python BrioKafka.py
"
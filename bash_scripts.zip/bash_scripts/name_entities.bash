#!/bin/bash
screen -dm name_entities
screen -S name_entities -X stuff "cd /media/hth/disk1/TextSum/modules/NER
source ~/anaconda3/etc/profile.d/conda.sh && conda activate NERnltk
python app.py
"
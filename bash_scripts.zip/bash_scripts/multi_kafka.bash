#!/bin/bash
screen -dm multi_kafka
screen -S multi_kafka -X stuff "cd /media/hth/disk1/TextSum/modules/root_kafka
source ~/anaconda3/etc/profile.d/conda.sh && conda activate kakfa
python multi_kafka.py
"
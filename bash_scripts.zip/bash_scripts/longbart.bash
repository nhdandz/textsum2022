#!/bin/bash
screen -dm longbart
screen -S longbart -X stuff "cd /media/hth/disk1/TextSum/Single/pegasus-xsum
source ~/anaconda3/etc/profile.d/conda.sh && conda activate test
python LongBartKafka.py
"
#!/bin/bash
screen -dm m_lexrank
screen -S m_lexrank -X stuff "cd /media/hth/disk1/TextSum/Multi/MulTexRank
source ~/anaconda3/etc/profile.d/conda.sh && conda activate kakfa
python multi_lexrank.py
"
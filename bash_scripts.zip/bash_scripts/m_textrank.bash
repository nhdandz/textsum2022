#!/bin/bash
screen -dm m_textrank
screen -S m_textrank -X stuff "cd /media/hth/disk1/TextSum/Multi/MulTexRank
source ~/anaconda3/etc/profile.d/conda.sh && conda activate kakfa
python multi_texrank.py
"
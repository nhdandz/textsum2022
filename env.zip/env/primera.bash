python3 -m venv primera_envs
source ./primera_envs/bin/activate
pip install -r primera_envs.txt

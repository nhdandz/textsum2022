python3 -m venv single_root_envs
source ./single_root_envs/bin/activate
pip install -r single_root_envs.txt

python3 -m venv bertext_envs
source ./bertext_envs/bin/activate
pip install -r bertext_envs.txt -f https://download.pytorch.org/whl/torch_stable.html
